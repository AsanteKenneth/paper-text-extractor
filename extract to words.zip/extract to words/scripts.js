let videoStream;
const video = document.getElementById('video');
const fileInput = document.getElementById('fileInput');
const captureBtn = document.getElementById('captureBtn');
const imagePreview = document.getElementById('imagePreview');
const extractBtn = document.getElementById('extractBtn');
const outputText = document.getElementById('outputText');

fileInput.addEventListener('change', function(event) {
  const file = event.target.files[0];
  const reader = new FileReader();

  reader.onload = function() {
    const img = new Image();
    img.src = reader.result;
    imagePreview.innerHTML = '';
    imagePreview.appendChild(img);
    showElement(imagePreview);
    hideElement(video);
  };

  reader.readAsDataURL(file);
});

captureBtn.addEventListener('click', () => {
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

  const img = new Image();
  img.src = canvas.toDataURL();
  imagePreview.innerHTML = '';
  imagePreview.appendChild(img);
  showElement(imagePreview);
  hideElement(video);
});

extractBtn.addEventListener('click', () => {
  const img = imagePreview.querySelector('img');
  if (!img) {
    alert('Please capture or upload an image first.');
    return;
  }

  Tesseract.recognize(
    img.src,
    'eng',
    { logger: m => console.log(m) }
  ).then(({ data: { text } }) => {
    outputText.textContent = text;
  });
});

// Start camera
navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => {
    videoStream = stream;
    video.srcObject = stream;
    showElement(video);
    hideElement(imagePreview);
  })
  .catch(error => {
    console.error('Error accessing camera:', error);
  });

function showElement(element) {
  element.style.display = 'block';
}

function hideElement(element) {
  element.style.display = 'none';
}

// Stop camera when navigating away
window.addEventListener('beforeunload', () => {
  if (videoStream) {
    videoStream.getTracks().forEach(track => {
      track.stop();
    });
  }
});
